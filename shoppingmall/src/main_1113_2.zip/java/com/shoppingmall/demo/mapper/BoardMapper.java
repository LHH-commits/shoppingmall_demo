package com.shoppingmall.demo.mapper;

public interface BoardMapper {

}
