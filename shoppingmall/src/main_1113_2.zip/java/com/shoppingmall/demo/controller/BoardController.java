package com.shoppingmall.demo.controller;

public class BoardController {

}
