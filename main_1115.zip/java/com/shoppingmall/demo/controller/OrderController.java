package com.shoppingmall.demo.controller;

import org.springframework.stereotype.Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
}
