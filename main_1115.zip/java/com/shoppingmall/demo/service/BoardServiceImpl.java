package com.shoppingmall.demo.service;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.shoppingmall.demo.domain.Board;
import com.shoppingmall.demo.domain.Pagination;
import com.shoppingmall.demo.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService {
    @Autowired
    BoardMapper boardmapper;

    @Override
    public List<Board> selectBoardList(Map<String, Object> params) {
        return boardmapper.selectBoardList(params);
    }

    @Override
    public int countBoardByType(String bType) {
        return boardmapper.countBoardByType(bType);
    }

    @Override
    public void insertBoard(Board board) {
        boardmapper.insertBoard(board);
    }
    
    @Transactional
    @Override
    public Board selectBoardBid(int bId) {
    	boardmapper.countViews(bId);
        return boardmapper.selectBoardBid(bId);
    }

    @Override
    public void deleteBoard(int bId) {
        boardmapper.deleteBoard(bId);
    }

    @Override
    public void updateBoard(Board board) {
        boardmapper.updateBoard(board);
    }
}
